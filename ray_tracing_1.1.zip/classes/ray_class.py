"""
ray class
@author: Slawa
"""

import os
import sys
Path=os.path.dirname((os.path.abspath(__file__)))
sys.path.append(Path)

import numpy as np
import matplotlib.pyplot as plt
Pi=np.pi

class ray_class():
    def __init__(self,X,A,L=0):
        """X0 is the starting point
        A is the vector defining the ray
        L is the optical path"""
        self.L=L
        self.X=np.array(X)
        self.A=np.array(A)/np.sum(np.array(A)**2) #normalization
        self.Xstory=[np.array(X)]
        self.Astory=[np.array(A)/np.sum(np.array(A)**2)]
    
    X=np.array([0.,0.,0.]) #start coordinate
    A=np.array([0.,0.,0.]) #vector defining the ray
    a=np.array([0.,0.,0.]) #direction
    Lost=False #status if missed a mirror
    Xstory=None #the propagation story
    Astory=None
    
    def length(self):
        if len(self.Xstory) == 1:
            return 0
        else:
            return np.sum([(np.sum([(self.Xstory[i+1]-self.Xstory[i])**2]))**0.5 
                           for i in range(len(self.Xstory)-1)])
    
    def reflection(self,X,A):
        """define new angle A after reflection at X"""
        X1=X
        self.Xstory.append(np.array(X1))
        self.Astory.append(np.array(A))
        self.X=np.array(X1)
        self.A=np.array(A)/np.sum(np.array(A)**2) #normalization
 
def angular_conus(angle,Nrays):
    """angle is the conus angle in radians; Nrays in the number of rays"""
    rays=[ray_class([0,0,0],[np.cos(angle),np.sin(angle)*np.cos(phi),np.sin(angle)*np.sin(phi)],0) 
                            for phi in np.linspace(-Pi,Pi,Nrays)]
    return rays

def gaussian_angular_distribution(a,N,Nsub0=10):
    """a is the angle defining the divergence on the e**-2 intensity level, N number of rays
    Nsub is the angular discretization"""
    Nsub=Nsub0+2
    Levels=np.linspace(1/Nsub/2,1-1/Nsub/2,Nsub-2)
    angles=(-np.log(Levels)*a**2/2)**0.5
    n=int(N/Nsub) #number of rays in each conus
    rays=[]
    for ConAng in angles:
        rays+=[ray_class([0,0,0],[np.cos(ConAng),np.sin(ConAng)*np.cos(phi),np.sin(ConAng)*np.sin(phi)],0) 
                        for phi in np.linspace(-Pi,Pi,n)]
    return rays

def gaussian_spaceYangle_distribution(W,Ns,Wa,Na,Nsub0=10):
    """a angle defining the divergence on the e**-2 intensity level, N number of rays
    Nsub is the angular discretization"""
    Nsub=Nsub0+2
    Levels=np.linspace(1/Nsub/2,1-1/Nsub/2,Nsub-2)
    angles=(-np.log(Levels)*Wa**2/2)**0.5
    radii=(-np.log(Levels)*W**2/2)**0.5
    # print(radii)
    ns=int(Ns/Nsub) #number of rays in each conus
    na=int(Na/Nsub) #number of rays in each conus
    rays=[]
    #central point
    for ConAng in angles:
            rays+=[ray_class([0,0,0],[np.cos(ConAng),np.sin(ConAng)*np.cos(phi),np.sin(ConAng)*np.sin(phi)],0) 
                        for phi in np.linspace(-Pi,Pi,na)]
    #all other points
    for r in radii:
        points=[[0,r*np.cos(a),r*np.sin(a)] for a in np.linspace(-Pi,Pi,ns)]
        # print(points,'\n')
        for p in points:
            for ConAng in angles:
                rays+=[ray_class(p,[np.cos(ConAng),np.sin(ConAng)*np.cos(phi),np.sin(ConAng)*np.sin(phi)],0) 
                            for phi in np.linspace(-Pi,Pi,na)]
    return rays